#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 10 12:26:59 2019

@author: zzhu3
"""

#!python
#cython: language_level=3

from time import time
import subprocess
import os
import pickle
from collections import Counter
import fcntl
import pandas as pd
import numpy as np
from statistics import median
import argparse
import gzip





#%%
def alignFastq(fastqPath, samPath, btindexName, bowtieOptions, nthreads):
    '''
    use bowtie2 to align reads in a fastq
    '''
    
    t0 = time()
    print(f'aligning {fastqPath} using {nthreads} processes...')
    bcmd = f'bowtie2 -p {nthreads} {bowtieOptions} -x {btindexName} -U {fastqPath} -S {samPath}'
    subprocess.run(bcmd, shell=True)
    print(f'finished aligning {fastqPath}, {time() - t0} s \n')
    

#%%
def readMerge(r1file, r2file, i1file, laneNumber, chunkNumber, outputFile, outputPath, barcodeLen, umiLen):
    '''
    merge barcodes from R1 with the header of R2 and outputs the new header 
    along with reads from R2 in a new fastq
    
    also processes barcode info to barcode selection to save on I/O operations
    
    
    example:
        
        'R1 fastq'        
        @D000684:779:H53GNBCXY:1:1101:1198:2139 1:N:0:AAATGTGC\n
        TNTCCTCGTTACCGATTGCATGCCCG\n
        +\n
        G#<GGGIIIIIIIIIIIIIIIIIIII\n
        
        'R2 fastq'
        @D000684:779:H53GNBCXY:1:1101:1198:2139 2:N:0:AAATGTGC\n
        AGATCTCTTGCACAGCATGATGAATATAGTTAATAAAACAGCATTGTACATTTCAAAATTGCCAAGTGTTAATTTCAAGTGTTCTCACCACAAAAATT\n
        +\n
        GGGGGIIIIIIIIIIIIIIIGIIIIIIIIIIGIIGIIGGIGGGIGIIGGIIIIGIIIGIIIIIIIIGGIIIIGIGIIIIGGGGGIIIIIGIIIIIGGA\n
        
        'I1 fastq'        
        @D000684:779:H53GNBCXY:1:1101:1198:2139 1:N:0:AAATGTGC\n
        AAATGTGC\n
        +\n
        IIIIIIII\n
        
            sample index: AAATGTGC
            cell barcode: TNTCCTCGTTACCGAT
                barcodeLen = length of 'TNTCCTCGTTACCGAT' = 16    
            headerExtrLen = length of ' 1:N:0:' = 7
                
        new merged fastq:
        @D000684:779:H53GNBCXY:1:1101:1198:2139_sample_AAATGTGC_cell_TNTCCTCGTTACCGAT_umi_TGCATGCCCG\n
        AGATCTCTTGCACAGCATGATGAATATAGTTAATAAAACAGCATTGTACATTTCAAAATTGCCAAGTGTTAATTTCAAGTGTTCTCACCACAAAAATT\n
        +\n
        GGGGGIIIIIIIIIIIIIIIGIIIIIIIIIIGIIGIIGGIGGGIGIIGGIIIIGIIIGIIIIIIIIGGIIIIGIGIIIIGGGGGIIIIIGIIIIIGGA\n
        
    '''
    
    t = time()
    print(f'merging lane {laneNumber} chunk {chunkNumber}...')
    fR1 = open(r1file)
    fR2 = open(r2file)
    fI1 = open(i1file)
    try:
        counter2 = 0
        counter3 = 0
        counter = 0
        pathFreqDict = {}
        pathset = set()
        sampleFreqDict = {}
        sampleset = set()
        barFreqDict = {}
        barset = set()
        notEOF = True
        while notEOF:
            rawR1 = []
            rawI1 = []
            readsR2 = []
            iBlock = 0
            while iBlock < (5000 * 4):
                r1Read = fR1.readline()
                r2Read = fR2.readline()
                i1Read = fI1.readline()
                if not r1Read:
                    notEOF = False
                    break
                rawR1.append(r1Read)
                readsR2.append(r2Read)
                rawI1.append(i1Read)
                counter2 += 1
                iBlock += 1
            counter3 += 1
            #in case last block before EOF is empty
            if not rawR1:
                break
            #barcode and umi from R1    
            seqR1 = rawR1[1::4]
            cellBar = [x[:barcodeLen] for x in seqR1]
            umi = [x[barcodeLen:(barcodeLen + umiLen)] for x in seqR1]
            #sample index from I1
            seqI1 = rawI1[1::4]
            sampleInd = [x[:-1] for x in seqI1]
            #check barcodes
            cellPath = [f'sample_{x[0]}/cell_{x[1]}' for x in zip(sampleInd, cellBar)]
            n = len(cellPath)
            counter += n
            i = 0
            while i < n:
                if cellPath[i] in pathset:
                    pathFreqDict[cellPath[i]] += 1
                else:
                    pathset.add(cellPath[i])
                    pathFreqDict[cellPath[i]] = 1
                if sampleInd[i] in sampleset:
                    sampleFreqDict[sampleInd[i]] += 1
                else:
                    sampleset.add(sampleInd[i])
                    sampleFreqDict[sampleInd[i]] = 1
                if cellBar[i] in barset:
                    barFreqDict[cellBar[i]] += 1
                else:
                    barset.add(cellBar[i])
                    barFreqDict[cellBar[i]] = 1
                i += 1
            #reads from R2 and merge            
            headerR2 = readsR2[0]
            headerTrimIndex = len(headerR2) - headerR2.index(' ')
            readsR2[::4] = [(x[0][:-headerTrimIndex] + '_sample_' + x[1] + '_cell_' + x[2] + '_umi_' + x[3] + '\n') for x in zip(readsR2[::4], sampleInd, cellBar, umi)]
            writeStr = ''
            writeStr = writeStr.join(readsR2)
            #write to file
            with open(outputFile, 'a') as f:
                f.write(writeStr)
    finally:
        with open(f'{outputPath}/paths{laneNumber}_{chunkNumber}','wb') as f:
            pickle.dump(pathFreqDict, f)
        with open(f'{outputPath}/sampleInd{laneNumber}_{chunkNumber}','wb') as f:
            pickle.dump(sampleFreqDict, f)
        with open(f'{outputPath}/cellBarcode{laneNumber}_{chunkNumber}','wb') as f:
            pickle.dump(barFreqDict, f)
        fR1.close()
        fR2.close()
        fI1.close()
        print(f'finished merging lane {laneNumber} chunk {chunkNumber}, {counter} reads, {time() - t} s')    
    
    
    

#%%
def barcode_selection(laneNumber, inputDir, outputDir, barcodeLen, sampleIndexLen, cellReadsCutoff, sampleReadsCutoff):
    '''
    iterate through all cell barcodes from reads from a sequencing lane and
    returns sample_index/barcode combinations that meet the specified cutoffs 
    in a pickle
    
    inputs are pickles of dicts of cell barcode and sample index frequencies
    from readMerge(). 
    '''
    t0 = time()
    print(f'processing lane {laneNumber} barcodes...')
    #load barcode counts from file
    pathsFreqDict = {}
    pathsFreqDict = Counter(pathsFreqDict)
    pathsset = set()
    sampleFreqDict = {}
    sampleFreqDict = Counter(sampleFreqDict)
    sampleset = set()
    barFreqDict = {}
    barFreqDict = Counter(barFreqDict)
    barset = set()
    i = 0
    while os.path.isfile(f'{inputDir}/paths{laneNumber}_{i}'):
        with open(f'{inputDir}/paths{laneNumber}_{i}','rb') as f:
            pd = pickle.load(f)
            pathsFreqDict += pd
        with open(f'{inputDir}/sampleInd{laneNumber}_{i}','rb') as f:
            sd = pickle.load(f)
            sampleFreqDict += sd
        with open(f'{inputDir}/cellBarcode{laneNumber}_{i}','rb') as f:
            bd = pickle.load(f)
            barFreqDict += bd        
        i += 1
    #select barcodes based on cutoff
    nreadsSelected = 0
    nreadsTotal = 0
    for barcode, freq in pathsFreqDict.items():
        if freq > cellReadsCutoff:
            pathsset.add(barcode)
            nreadsSelected += freq
        nreadsTotal += freq
    for sampleIndex, freq in sampleFreqDict.items():
        if freq > sampleReadsCutoff:
            sampleset.add(sampleIndex)
    for barcode, freq in barFreqDict.items():
        if freq > cellReadsCutoff:
            barset.add(barcode)
    #dump results in pickles for later use
    with open(f'{outputDir}/paths_set{laneNumber}','ab') as f1:
        pickle.dump(pathsset, f1)
    with open(f'{outputDir}/sampleIndex_set{laneNumber}','ab') as f2:
        pickle.dump(sampleset, f2)
    with open(f'{outputDir}/cellBarcode_set{laneNumber}','ab') as f3:
        pickle.dump(barset, f3)
    #record summary information
    t1 = time()    
    nUniqueBarcodesComb = len(pathsFreqDict)
    nSelectedBarcodes = len(pathsset)
        #nUniqueBars = len(barFreqDict)    
    outputStr = f'found {nUniqueBarcodesComb} unique sample index/barcode combinations in lane {laneNumber},\n\t{nSelectedBarcodes} selected  with over {cellReadsCutoff} reads,\n\t{nreadsSelected} out of {nreadsTotal} reads to be used, {t1 - t0} s \n'
    print(outputStr)
    with open('summary.txt','a') as f:
        f.write(outputStr)  
    return barFreqDict, barset, [nreadsTotal, nreadsSelected]

     
#%%
def lxSplit(filename, inputDir, outputDir, lines, ext='.fastq'):
    '''
    wrapper for linux command "split" to split large fastq for multiprocessing
    '''
    
    splitcmd = f'split -a 4 -d -l {lines} {inputDir}/{filename}{ext} {outputDir}/{filename}_chunk'
    subprocess.run(splitcmd, shell=True)
    
#%%
def lxDecompress(filename, inputDir, outputDir):
    '''
    wrapper for linux gzip to extract fastq inputs
    '''
    
    extractcmd = f'gzip -d -c {inputDir}/{filename}.fastq.gz > {outputDir}/{filename}.fastq'
    subprocess.run(extractcmd, shell=True)    
    
#%%
def lxDelDir(dirpath):
    '''
    wrapper for linux delete command to recursively delete directory
    '''
    
    delcmd = f'rm -rf {dirpath}'
    subprocess.run(delcmd, shell=True)

#%%
def get_filepaths(directory):
    """
    adapted from "Johnny" (https://stackoverflow.com/users/1779256/johnny)
    
    This function will generate the file names in a directory 
    tree by walking the tree either top-down or bottom-up. 
    """
    file_paths = []
    # Walk the tree.
    for root, directories, files in os.walk(directory):
        for filename in files:
            # Join the two strings in order to form the full filepath.
            filepath = os.path.join(root, filename)
            file_paths.append(filepath)  # Add it to the list.
    return file_paths  


#%%
def samSort(inputDir, outputDir, sam_name, path_set_name, sampleIndLen, barLen):
    '''
    sort reads in SAM files by sample index and cell barcode and store as 
    seperate SAM files
    '''
    print(f'sorting {sam_name}...')
    t = time()    
    #load inputs
    path0 = os.getcwd()
    os.chdir(inputDir)
    with open(sam_name) as f:
        sam = f.readlines()
    with open(path_set_name, 'rb') as f:
        path_set = pickle.load(f)
    os.chdir(outputDir)
    #seperate reads by barcodes and write in blocks
    #   sample line: 'D000684:779:H53GNBCXY:1:1110:3316:42789_sample_GGGCAAAT_cell_TTCTACAGTGACTCAT_umi_AGGCGGTTGG\t16\tchr5\t82276115\t1\...'
    writeDict = {}
    count = 0
    n = 0
    writeCount = 0
    for line in sam:
        i = line.index('sample')
        sampleName = line[i:(i + 7 + sampleIndLen)]
        i += (7 + sampleIndLen + 1)
        cellName = line[i:(i + 5 + barLen)]
        cellPath = sampleName + '/' + cellName
        count += 1
        n += 1
        if cellPath in path_set:
            if cellPath in writeDict:
                writeDict[cellPath].append(line)
            else:
                writeDict[cellPath] = [line]
            writeCount += 1
        if n == 500000:
            n = 0
            for cell in writeDict:                
                with open(f'{cell}.sam', 'a') as f:
                    fcntl.flock(f, fcntl.LOCK_EX)
                    w = ''
                    w = w.join(writeDict[cell])
                    f.write(w)
                    fcntl.flock(f, fcntl.LOCK_UN)
            writeDict = {}
    #last partial block
    if writeDict:
        for cell in writeDict:
            with open(f'{cell}.sam', 'a') as f:
                fcntl.flock(f, fcntl.LOCK_EX)
                w = ''
                w = w.join(writeDict[cell])
                f.write(w)
                fcntl.flock(f, fcntl.LOCK_UN)            
    print(f'{count} reads total from {sam_name}, {writeCount} written, {time() - t} s')
    os.chdir(path0)
    

#%%
def samSort_ignoreSampleInd(inputDir, outputDir, sam_name, bar_set_name, sampleIndLen, barLen):
    '''
    sort reads in SAM files by sample index and cell barcode and store as 
    seperate SAM files
    '''
    print(f'sorting {sam_name}...')
    t = time()    
    #load inputs
    path0 = os.getcwd()
    os.chdir(inputDir)
    with open(sam_name) as f:
        sam = f.readlines()
    with open(bar_set_name, 'rb') as f:
        bar_set = pickle.load(f)
    os.chdir(outputDir)
    #seperate reads by cell barcode and write in blocks
    #   sample line: 'D000684:779:H53GNBCXY:1:1110:3316:42789_sample_GGGCAAAT_cell_TTCTACAGTGACTCAT_umi_AGGCGGTTGG\t16\tchr5\t82276115\t1\...'
    writeDict = {}
    count = 0
    n = 0
    writeCount = 0
    for line in sam:
        i = line.index('cell')
        i += 5
        cellName = line[i:(i + barLen)]
        count += 1
        n += 1
        if cellName in bar_set:
            if cellName in writeDict:
                writeDict[cellName] += line
            else:
                writeDict[cellName] = line
            writeCount += 1
        if n == 500000:
            n = 0
            for cell, reads in writeDict.items():                
                with open(f'cell_{cell}.sam', 'a') as f:
                    fcntl.flock(f, fcntl.LOCK_EX)
                    f.write(reads)
                    fcntl.flock(f, fcntl.LOCK_UN)
            writeDict = {}
    #last partial block
    if writeDict:
        for cell, reads in writeDict.items():
            with open(f'cell_{cell}.sam', 'a') as f:
                fcntl.flock(f, fcntl.LOCK_EX)
                f.write(reads)
                fcntl.flock(f, fcntl.LOCK_UN)
    print(f'{count} reads total from {sam_name}, {writeCount} written, {time() - t} s')
    os.chdir(path0)
    
    


#%%
def readSelection(inputSamPath, outputDir, umiLen, cellBarcodeLen, sampleIndLen, maxReadsOffset, selectOne=False, ignoreSampleIndex=False, compress=True):
    '''
    use alignment results to select valid reads from reads with the same UMI
    
    valids reads must be successfully mapped to the referance genome, 
    as well as be mapped to the most popular chromosome within reads that 
    share the same UMI, and have mapped locations on the chromosome within 
    maxReadsOffset of the median mapped location
    '''
    
    
    path0 = os.getcwd()
    
    colNames = ['qname','flag','rname','pos','mapq','CIGAR','rnext','pnext','templ_len','seq','qual','AS','XN','XM','XO','XG','NM','MD','YT']
    rml=['flag','mapq','CIGAR','rnext','pnext','templ_len','AS','XN','XM','XO','XG','NM','MD','YT']
    sam = pd.read_csv(inputSamPath, sep='\t', header=None, names=colNames, index_col=False, lineterminator='\n')
        
    for x in rml:
        del sam[f'{x}']
        
    headers = '@' + sam.qname
    umi = [line[-umiLen:] for line in headers] 
    sampleName = headers[0][-(umiLen + 5 + cellBarcodeLen + 6 + sampleIndLen):-(umiLen + 5 + cellBarcodeLen + 6)]
    cellName = headers[0][-(umiLen + 5 + cellBarcodeLen):-(umiLen + 5)]
    pos = sam.pos
    rname = sam.rname
    seqs = sam.seq
    quals = sam.qual
    
    saml = list(zip(umi, rname, pos, headers, seqs, quals))
    nReads0 = len(saml)
    
    #remove reads that failed to align   
    saml = [x for x in saml if x[1] != '*']
    
    saml.sort()
    rname = list(zip(*saml))[1]
    umi = list(zip(*saml))[0]
    umin = Counter(umi)
    
    lcell = len(saml)

    
    #determine which 
    selectl = np.zeros(lcell, dtype = bool)
    i = 0
    while i < lcell:
        nreads = umin[saml[i][0]]
        chrs = rname[i:(i + nreads)]
        chrscounter = Counter(chrs)
        chrsmode = chrscounter.most_common()[0][0]
        #find chromosome with most alignment
            
        j = 0
        poslist = []
        while j < nreads:
            poslist.append(saml[i + j][2])
            j += 1
            
        medpos = median(poslist)
        if selectOne:
            k = 0
            prevreadOffset = 1000
            while k < nreads:
                offset = saml[i + k][2] - medpos
                if (rname[i + k] == chrsmode) and (offset < prevreadOffset):
                    medInd = k
                    prevreadOffset = offset
                k += 1
            selectl[i + medInd] = True
        else:
            k = 0
            while k < nreads:
                if (rname[i + k] == chrsmode) and ((saml[i + k][2] - medpos) < maxReadsOffset):
                    selectl[i + k] = True
                k += 1
                
        i += nreads
    '''    
    #testing
    pick = list(zip(selectl, saml))
    with open(f'{inputSamPath}_selection', 'wb') as f:
        pickle.dump(pick, f)
    '''
    nReadsSelected = 0
    writeBuf = ''
    i = 0
    for i in range(lcell):
        if selectl[i]:
            writeBuf += saml[i][3] + '\n' + saml[i][4] + '\n' + '+\n' + saml[i][5] + '\n'
            nReadsSelected += 1
            
    os.chdir(outputDir)
    if not ignoreSampleIndex:
        if not os.path.isdir(f'sample_{sampleName}'):
            os.makedirs(f'sample_{sampleName}',exist_ok=True)
        os.chdir(f'sample_{sampleName}')
        
    if compress:
        bwriteBuf = writeBuf.encode()
        with gzip.open(f'cell_{cellName}.fastq.gz', 'wb') as f:
            f.write(bwriteBuf)
    else:
        with open(f'cell_{cellName}.fastq', 'w') as f:
            f.write(writeBuf)
        
    os.chdir(path0)
    
    summary = [cellName, nReads0, lcell, nReadsSelected]
    
    if ignoreSampleIndex:
        with open('readSelectionCombined', 'ab') as f:
            fcntl.flock(f, fcntl.LOCK_EX)
            pickle.dump(summary, f)
            fcntl.flock(f, fcntl.LOCK_UN)
    else:
        with open('readSelection', 'ab') as f:
            fcntl.flock(f, fcntl.LOCK_EX)
            pickle.dump(summary, f)
            fcntl.flock(f, fcntl.LOCK_UN)
    
#%%
def str2bool(v):
    '''
    allows input of boolean values from command line
    '''
    if isinstance(v, bool):
       return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')
        
  