# -*- coding: utf-8 -*-
"""
Created on Thu Jun 20 13:37:31 2019

@author: g06t
"""
import al_functions_m41 as af
from time import time
import os
from multiprocessing import Pool
import pickle
import psutil
import numpy as np
import argparse
import configparser
import sys
import fnmatch
from glob import glob


#%%
def main():    
    t0 = time()   
    #load config file
    config = configparser.ConfigParser()
    config.read('config.ini')
    defaultValues = config['inputDefaults']
    bowtieOptions = config['bowtieAlignOptions']
    #parse user inputs
    parser = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter, 
                             epilog='example: \n \t python FASTR.py --n example_S1_L001_R1_001.fastq --i /home/seqs/example --r /home/results/example_run --ig True --u False')
    parser.add_argument('--n', type=str, 
                        help='filename of any read (ex: example_L001_R1_001.fastq) *not the path to the files*')
    parser.add_argument('--i', type=str, default=defaultValues['inputDir'],
                        help=f"(optional) path of the directory of the input fastq files, default: {defaultValues['inputDir']}")
    parser.add_argument('--r', type=str, default=defaultValues['outputDir'],
                        help=f"(optional) path of the directory for output, default: {defaultValues['outputDir']}")
    parser.add_argument('--ind', type=str, default=f"{bowtieOptions['bowtie2indexDir']}/{bowtieOptions['bowtie2indexName']}",
                        help=f"(optional) path and name of the bowtie reference index, default: {bowtieOptions['bowtie2indexDir']}/{bowtieOptions['bowtie2indexName']}")
    parser.add_argument('--cb', type=int, default=int(defaultValues['cellBarcodeLength']),
                        help=f"length of cell barcode; default: {defaultValues['cellBarcodeLength']} bp")
    parser.add_argument('--sl', type=int, default=int(defaultValues['sampleIndexLength']),
                        help=f"length of sample index; default: {defaultValues['sampleIndexLength']} bp")
    parser.add_argument('--ul', type=int, default=int(defaultValues['umiLength']),
                        help=f"length of UMI; default = {defaultValues['umiLength']} bp")
    parser.add_argument('--cc', type=int, default=int(defaultValues['cellreadsCutoff']),
                        help=f"cell reads cutoff: minimum number of reads required for a cell barcode to be valid; default: {defaultValues['cellreadsCutoff']}")
    parser.add_argument('--sc', type=int, default=int(defaultValues['sampleReadsCutoff']),
                        help=f"sample reads cutoff: minimum number of reads required for a sample index to be valid; default: {defaultValues['sampleReadsCutoff']}")
    parser.add_argument('--ro', type=int, default=int(defaultValues['maxReadOffset']),
                        help=f"read offset: maximum deviation from the median alignment position of a group of reads with identical UMIs for a read to be valid; default: {defaultValues['maxReadOffset']}")
    parser.add_argument('--so', type=af.str2bool, nargs='?', const=True, default=defaultValues.getboolean('selectOnePerUMI'),
                        help=f"select one: choose whether to select one read per UMI (True) or keep all valid reads (False); default: {defaultValues['selectoneperumi']}")
    parser.add_argument('--ig', type=af.str2bool, nargs='?', const=True, default=defaultValues.getboolean('ignoreSampleIndex'),
                        help=f"ignore sample index: if set to ""True,"" also sort reads as if they have identical sample index and output to another directory; default: {defaultValues['ignoreSampleIndex']}")
    parser.add_argument('--u', type=af.str2bool, nargs='?', const=True, default=defaultValues.getboolean('userConfirmation'),
                        help=f"pause program for user to confirm parameters before starting; default: {defaultValues['userConfirmation']} (***set to ''False'' to avoid hang in automated runs***)")
    parser.add_argument('--gz', type=af.str2bool, nargs='?', const=True, default=defaultValues.getboolean('compressedOutput'),
                        help=f"compressed output; default: {defaultValues['compressedOutput']} (use ''False'' to keep results as uncompressed fastq")
    parser.add_argument('--sam', type=af.str2bool, nargs='?', const=True, default=defaultValues.getboolean('keepSAM'),
                        help=f"keep SAM: if set to ""True"", keeps SAM files from Bowtie2 alignment; default: {defaultValues['keepSAM']}")
    args = parser.parse_args()
    #transfer inputs to variables
    filename = args.n 
    inputDir0 = args.i
    outputDir0 = args.r
    refind = args.ind
    barcodeLen = args.cb 
    sampleIndLen = args.sl  
    umiLen = args.ul 
    cellReadsCutoff = args.cc 
    sampleReadsCutoff = args.sc 
    maxReadOffset = args.ro 
    selectOne = args.so 
    ignoreSampleInd = args.ig 
    waitForConfirm = args.u
    gzresults = args.gz
    keepSAM = args.sam
    i = filename.index('S1_L')
    basename = filename[:(i + 4)]
    #set input directory
    p0 = os.getcwd()
    if inputDir0 == 'current working directory':
        inputDir0 = p0
        inputstr = 'input directory: current working directory'
        print(inputstr)
    else:
        inputstr = f'input directory: {inputDir0}'
        print(inputstr)
    #check if inputs are compressed    
    for file in os.listdir(inputDir0):
        if fnmatch.fnmatch(file, f'{filename}*'):
            fullFilename = file
            break
    if '.gz' in fullFilename:
        compressedInputs = True
    else:
        compressedInputs = False
    #find the number of seq lanes present
    os.chdir(inputDir0)
    r1base1 = '_R1_001'
    r2base1 = '_R2_001'
    i1base1 = '_I1_001'
    if compressedInputs:
        fext = '.fastq.gz'
    else:
        fext = '.fastq'
    lanes = 0
    while True:
        n = str(lanes + 1).zfill(3)
        r1filename = basename + n + r1base1 + fext
        r2filename = basename + n + r2base1 + fext
        i1filename = basename + n + i1base1 + fext
        if os.path.isfile(r1filename) and os.path.isfile(r2filename) and os.path.isfile(i1filename):
            lanes += 1            
        else:
            break   
    if outputDir0 == 'new directory in input directory':
        outputDir0 = f'{inputDir0}/{basename[:-2]}'
        os.mkdir(outputDir0)
        outputstr = 'output directory: new directory in input directory'
        print(outputstr)
    else:
        outputstr = f'output directory: {outputDir0}'
        print(outputstr)        
    #make output directory if it does not exist
    if not os.path.isdir(outputDir0):
        os.mkdir(outputDir0)
    os.chdir(outputDir0)
    #record input/output directory locations
    with open('summary.txt','a') as f:
        wrtstr = inputstr + '\n' + outputstr + '\n'
        f.write(wrtstr)
    #check bowtie2 reference index 
    refind = f'{p0}/{refind}'
    if not glob(refind + '*'):
        print(f'Error: no bowtie index found at {refind}!')
        return -1
    #display/record user inputs 
    l = {'basename':basename, 'bowtie index': refind, 'barcode_length':barcodeLen,'sampl.ind.len': sampleIndLen,'UMI len': umiLen,'cellReadsCutoff': cellReadsCutoff,'sampleReadsCutoff': sampleReadsCutoff,'maxReadOffset': maxReadOffset,'select one read per UMI': selectOne, 'combine reads from different sample indexes': ignoreSampleInd, 'number of lanes': lanes, 'user confirmation of inputs': waitForConfirm, 'compressed inputs': compressedInputs, 'keep SAMs': keepSAM}
    for x, y in l.items():
        sumstr0 = f'{x} :\t {y} \n'
        print(sumstr0)
        with open('summary.txt','a') as f:
            f.write(sumstr0)
    if waitForConfirm:
        p = input('proceed? (y to continue) \n')
        if p != 'y' and p != 'Y':
            sys.exit(0)            
    #calculate chunk size based on system resources
    nprocess = os.cpu_count()
    availMem = psutil.virtual_memory()[1]
    '''
    #unused for now (7/8/19); current version is not memory instensive, with memory use independent of chunk size
    processMem = availMem / nprocess
    maxnReads = processMem / 900        #max mem consumption is ~0.7 KB per read per process
    if maxnReads > 1000000:
        chunkSize = 1000000             #samSort slows down dramatically with excessive chunk size
    else:
        chunkSize = int(maxnReads)
    '''
    chunkSize = 5000000    
    #record system resource information
    iniStr = f'{availMem / 1073741824} GB memory available, running with {nprocess} processes \n\n'
    print(iniStr)
    with open('summary.txt','a') as f:
        f.write(iniStr)
    #make folders
    path0 = outputDir0
    if not os.path.isdir('chunks'):
        os.mkdir('chunks')
    os.chdir('chunks')
    pathC = os.getcwd()
    os.chdir(path0)
    if not os.path.isdir('merged_chunks'):
        os.mkdir('merged_chunks')
    os.chdir('merged_chunks')
    pathM = os.getcwd()
    os.chdir(path0)
    if not os.path.isdir('sams'):
        os.mkdir('sams')
    os.chdir('sams')
    pathS = os.getcwd()
    os.chdir(path0)
    if not os.path.isdir('sorted_sams'):
        os.mkdir('sorted_sams')
    os.chdir('sorted_sams')
    pathS2 = os.getcwd()
    os.chdir(path0)
    resultDirName = basename[:-5] + '_results'
    if not os.path.isdir(resultDirName):
        os.mkdir(resultDirName)
    os.chdir(resultDirName)
    pathR = os.getcwd()
    os.chdir(path0)
    if not os.path.isdir('sorted_sams_combined'):
        os.mkdir('sorted_sams_combined')
    os.chdir('sorted_sams_combined')
    pathS2c = os.getcwd()
    os.chdir(path0)    
    resultDirName += '_combined'
    if not os.path.isdir(resultDirName):
        os.mkdir(resultDirName)
    os.chdir(resultDirName)
    pathRc = os.getcwd()
    os.chdir(path0)
    #if inputs are compressed fastqs, decompress to a new directory and set that as input directory
    if compressedInputs:
        t1 = time()
        print('decompressing inputs...')
        if not os.path.isdir('extracted_inputs'):
            os.mkdir('extracted_inputs')
        os.chdir('extracted_inputs')
        pathEx = os.getcwd()
        os.chdir(path0)    
        i = 0
        inputlist = []
        while i < lanes:
            n = str(i + 1).zfill(3)
            r1filename = basename + n + r1base1 
            r2filename = basename + n + r2base1
            i1filename = basename + n + i1base1
            inputlist.append((r1filename, inputDir0, pathEx))
            inputlist.append((r2filename, inputDir0, pathEx))
            inputlist.append((i1filename, inputDir0, pathEx))
            i += 1
        with Pool() as pool:
            pool.starmap(af.lxDecompress, inputlist)    
        #set directory of extracted files as input directory
        inputDir0 = pathEx
        #log time
        t2 = time()
        summstrEx = f'finished decompressing inputs, {t2 - t1} s, {t2 - t0} s total\n\n'
        t1 = t2
        print(summstrEx)
        with open('summary.txt','a') as f:
            f.write(summstrEx)  
            
    #%%split inputs into chunks for multiprocessing
    t1 = time()
    print('making chunks...')
    i = 0
    inputlist = []
    lines = chunkSize * 4
    while i < lanes:
        n = str(i + 1).zfill(3)
        r1filename = basename + n + r1base1 
        r2filename = basename + n + r2base1
        i1filename = basename + n + i1base1
        inputlist.append((r1filename, inputDir0, pathC, lines))
        inputlist.append((r2filename, inputDir0, pathC, lines))
        inputlist.append((i1filename, inputDir0, pathC, lines))
        i += 1
    with Pool() as pool:
        pool.starmap(af.lxSplit, inputlist)    
    #log time
    t2 = time()
    print(f'finished making chunks, {t2 - t1} s, {t2 - t0} s total')
    t1 = t2
    #delete inputs to free disk space
    if compressedInputs:
        print('deleting extracted inputs...')
        af.lxDelDir(pathEx)
        print('finished deleting\n')
    
    #%%merge reads to prepare for alignment
    #   (multiprocess bowtie2 align changes the order of reads)
    print('merging chunks...')
    #finds number of chunks in each lane 
    nchunks = np.zeros(lanes, dtype=int)
    i = 0
    while i < lanes:
        nl = str(i + 1).zfill(3)
        j = 0
        while True:
            nc = str(j).zfill(4)
            r1chunkPath = pathC + '/' + basename + nl + r1base1 + '_chunk' + nc 
            if os.path.isfile(r1chunkPath):
                j += 1
            else:
                nchunks[i] = j
                break
        i += 1
        with open('summary.txt','a') as f:
            summStr = f'made {j} chunks for lane {i} \n\n'
            f.write(summStr)            
    #merging sample index and cell barcode from R1 and I1 to R2
    inputlist2 = []
    inputlist3 = []
    i = 0
    while i < lanes:
        nl = str(i + 1).zfill(3)
        j = 0
        while j < nchunks[i]:
            nc = str(j).zfill(4)
            r1chunk = pathC + '/' + basename + nl + r1base1 + '_chunk' + nc
            r2chunk = pathC + '/' + basename + nl + r2base1 + '_chunk' + nc
            i1chunk = pathC + '/' + basename + nl + i1base1 + '_chunk' + nc
            outputChunk = pathM + '/' + f'lane{i+1}_chunk{j}.fastq'
            samPath = pathS + '/' + f'lane{i+1}_chunk{j}.sam'
            laneN = i + 1
            chunkN = j
            j += 1
            inputlist2.append((r1chunk, r2chunk, i1chunk, laneN, chunkN, outputChunk, pathM, barcodeLen, umiLen))
            inputlist3.append((outputChunk, samPath))
        i += 1
    with Pool() as pool:
        pool.starmap(af.readMerge, inputlist2)    
    #record time
    t2 = time()
    print(f'finished merging chunks, {t2 - t1} s, {t2 - t0} s total')
    t1 = t2
    print('deleting original chunks...')
    af.lxDelDir(pathC)
    print('finished deleting\n')
    
    #%%align reads
    print('starting read alignment...')
    for item in inputlist3:
        fastqPath = item[0]
        samPath = item[1]
        af.alignFastq(fastqPath, samPath, refind, bowtieOptions['options'], nprocess)
    t2 = time()
    print(f'finished alignment, {t2 - t1} s, {t2 - t0} s total')
    t1 = t2
    
    #%%select sample indeces and cell barcodes
    print('starting barcode selection...') 
    barDict = {}
    barset = set()
    totalReads = 0
    selectedReads = 0
    i = 0
    while i < lanes:
        lanebarDict, lanebarset, summVals = af.barcode_selection(i + 1, pathM, pathS, barcodeLen, sampleIndLen, cellReadsCutoff, sampleReadsCutoff)
        barDict.update(lanebarDict)
        barset.update(lanebarset)
        totalReads += summVals[0]
        selectedReads += summVals[1]
        i += 1
    nBarcodes = len(barDict)
    nSelectedBarcodes = len(barset)
    summStr2 = f'{nBarcodes} total unique barcodes, {nSelectedBarcodes} with over {cellReadsCutoff} reads, {selectedReads} reads selected from a total of {totalReads} reads \n\n'
    with open('summary.txt','a') as f:
        f.write(summStr2)     
    t2 = time()
    print(summStr2)
    print(f'finished barcode selection, {t2 - t1} s, {t2 - t0} s total')
    t1 = t2
    #delete intermediate files
    print('deleting merged chunks...')
    af.lxDelDir(pathM)
    print('finished deleting\n')       
    
    #%%sort aligned reads by sample/cell    
    print('sorting SAMs by cell...')
    os.chdir(pathS)        
    sampleIndex_set = set()
    sortInputs = []
    sortCombinedInputs = []
    for i in range(lanes):
        for j in range(nchunks[i]):
            inputDir = pathS
            outputDir = pathS2
            outputDirc = pathS2c
            sam_name = f'lane{i + 1}_chunk{j}.sam'
            path_set_name = f'paths_set{i + 1}'
            bar_set_name = f'cellBarcode_set{i + 1}'
            sampleIndex_set_name = f'sampleIndex_set{i + 1}'
            sortInputs.append((inputDir, outputDir, sam_name, path_set_name, sampleIndLen, barcodeLen))
            sortCombinedInputs.append((inputDir, outputDirc, sam_name, bar_set_name, sampleIndLen, barcodeLen))            
            with open(sampleIndex_set_name, 'rb') as f:
                sampleIndex_set.update(pickle.load(f))        
    os.chdir(pathS2)    
    for sample in sampleIndex_set:
        if not os.path.isdir(f'sample_{sample}'):
            os.mkdir(f'sample_{sample}')
    os.chdir(path0)
    #combine reads with different sample indeces if user specified ignore sample index
    if ignoreSampleInd:
        with Pool() as pool:
            pool.starmap(af.samSort_ignoreSampleInd, sortCombinedInputs)
    else:
        with Pool() as pool:
            pool.starmap(af.samSort, sortInputs)
    t2 = time()
    summStr5 = f'finished SAM sorting, {t2 - t1} s, {t2 - t0} s total \n\n'
    t1 = t2
    print(summStr5)
    with open('summary.txt','a') as f:
        f.write(summStr5)     
    print('deleting intermediate files...')
    af.lxDelDir(pathS)
    print('finished deleting\n')    
    
    #%%select reads based on alignment position
    print('selecting reads...')    
    cellSamPaths = af.get_filepaths(pathS2)
    selectionInputs = []
    for cell in cellSamPaths:
        inputSampath = cell
        outputDir = pathR
        selectionInputs.append((inputSampath, outputDir, umiLen, barcodeLen, sampleIndLen, maxReadOffset, selectOne, False, gzresults))
    #ignore sample index: 
    #   reads with different indeces are assumed to be from the same sample
    if ignoreSampleInd:
        cellSamPathsc = af.get_filepaths(pathS2c)
        selectionInputsc = []
        for cell in cellSamPathsc:
            inputSampath = cell
            outputDir = pathRc
            selectionInputsc.append((inputSampath, outputDir, umiLen, barcodeLen, sampleIndLen, maxReadOffset, selectOne, ignoreSampleInd, gzresults))
        with Pool() as pool:
            pool.starmap(af.readSelection, selectionInputsc)
        #calculate and record summary
        f = open('readSelectionCombined', 'rb')
        summaryList = []
        while True:
            try:
                summaryList.append(pickle.load(f))
            except EOFError:
                break 
        f.close()
        nReads_correct_barcode = 0
        nReads_aligned = 0
        nReads_selected = 0
        for cell in summaryList:
            nReads_correct_barcode += cell[1]
            nReads_aligned += cell[2]
            nReads_selected += cell[3]
        percentCBar = format((nReads_correct_barcode / totalReads * 100), '.2f')
        percentAln = format((nReads_aligned / nReads_correct_barcode * 100), '.2f')
        percentSort = format((nReads_selected / nReads_aligned * 100), '.2f')
        percentOverall = format((nReads_selected / totalReads * 100), '.2f')
        summStr3 = f'(ignoring sample index) of {totalReads} total reads, {nReads_correct_barcode} found with valid barcodes ({percentCBar} %), \n    {nReads_aligned} aligned to genome ({percentAln} %), {nReads_selected} selected and sorted ({percentSort} % of aligned reads, {percentOverall} % of total) \n\n'
        with open('summary.txt','a') as f:
            f.write(summStr3)     
    #default mode:
    #   one directory for each sample index, with reads seperated accordingly
    else:
        with Pool() as pool:
            pool.starmap(af.readSelection, selectionInputs)
        #calculate and record summary
        f = open('readSelection', 'rb')
        summaryList = []
        while True:
            try:
                summaryList.append(pickle.load(f))
            except EOFError:
                break 
        f.close()
        nReads_correct_barcode = 0
        nReads_aligned = 0
        nReads_selected = 0
        for cell in summaryList:
            nReads_correct_barcode += cell[1]
            nReads_aligned += cell[2]
            nReads_selected += cell[3]
        percentCBar = format((nReads_correct_barcode / totalReads * 100), '.2f')
        percentAln = format((nReads_aligned / nReads_correct_barcode * 100), '.2f')
        percentSort = format((nReads_selected / nReads_aligned * 100), '.2f')
        percentOverall = format((nReads_selected / totalReads * 100), '.2f')
        summStr4 = f'of {totalReads} total reads, {nReads_correct_barcode} found with valid barcodes ({percentCBar} %), \n    {nReads_aligned} aligned to genome ({percentAln} %), {nReads_selected} selected and sorted ({percentSort} % of aligned reads, {percentOverall} % of total)\n\n'
        with open('summary.txt','a') as f:
            f.write(summStr4) 
    #record summary information
    t2 = time()
    summStr6 = f'finished reads selection, {t2 - t1} s, {t2 - t0} s total time \n\n'
    t1 = t2
    print(summStr6)
    with open('summary.txt','a') as f:
        f.write(summStr6) 
    #delete unecessary directories
    if ignoreSampleInd:
        af.lxDelDir(pathR)
        af.lxDelDir(pathS2)
        if not keepSAM:
            af.lxDelDir(pathS2c)
    else:
        af.lxDelDir(pathRc)
        af.lxDelDir(pathS2c)
        if not keepSAM:
            af.lxDelDir(pathS2)
    
    
if __name__ == '__main__':
    main()















